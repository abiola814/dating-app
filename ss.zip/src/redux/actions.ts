export const setUserState = (payload: any) =>{
    return { type: 'SET_USER_STATE',payload}
}